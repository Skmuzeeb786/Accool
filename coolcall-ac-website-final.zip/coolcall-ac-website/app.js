/* CoolCall – front-end demo. Data is kept in this browser's localStorage. */
const ADMIN = { user: "admin", pass: "admin123" };
const SLOTS = ["9:00 – 11:00 am", "11:00 am – 1:00 pm", "2:00 – 4:00 pm", "4:00 – 6:00 pm"];
const SLOT_LIMIT = 3;
const STATUSES = ["Pending", "Confirmed", "Completed", "Cancelled"];

const DB = {
  get(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v === null ? d : v; } catch (e) { return d; } },
  set(k, v) { localStorage.setItem(k, JSON.stringify(v)); }
};
const session = () => DB.get("cc_session", null);
const users = () => DB.get("cc_users", []);
const bookings = () => DB.get("cc_bookings", []);

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function todayISO() { return new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10); }
function nextPage() {
  const n = new URLSearchParams(location.search).get("next");
  return n && /^[a-z]+\.html(\?[A-Za-z0-9%=&_.+-]*)?$/.test(n) ? n : null;
}
function requireRole(role) {
  const s = session();
  if (!s || s.role !== role) {
    location.replace("login.html?next=" + encodeURIComponent((location.pathname.split("/").pop() || "index.html") + location.search));
    return null;
  }
  return s;
}
function logout() { localStorage.removeItem("cc_session"); location.href = "index.html"; }

function renderAuth() {
  const el = document.getElementById("authArea");
  if (!el) return;
  const s = session();
  if (!s) { el.innerHTML = '<a href="login.html" class="btn btn-ghost">Log in</a>'; return; }
  const home = s.role === "admin" ? "admin.html" : "book.html";
  el.innerHTML = '<a href="' + home + '" class="nav-user">' + esc(s.name) + '</a> <button class="btn btn-ghost" id="logoutBtn" type="button">Log out</button>';
  document.getElementById("logoutBtn").addEventListener("click", logout);
}

/* ---------- Home page ---------- */
function initHome() {
  const sel = document.getElementById("service"), link = document.getElementById("bookLink");
  if (!sel || !link) return;
  const upd = () => { link.href = "book.html?service=" + encodeURIComponent(sel.value); };
  sel.addEventListener("change", upd); upd();
}

/* ---------- Login page ---------- */
function initLogin() {
  const tabs = document.querySelectorAll("[data-tab]"), panels = document.querySelectorAll("[data-panel]");
  function show(name) {
    tabs.forEach(t => { const on = t.dataset.tab === name; t.classList.toggle("active", on); t.setAttribute("aria-selected", on); });
    panels.forEach(p => { p.hidden = p.dataset.panel !== name; });
  }
  tabs.forEach(t => t.addEventListener("click", () => show(t.dataset.tab)));
  show("user");

  const msg = id => document.getElementById(id);
  const go = (role) => {
    const n = nextPage();
    const page = n ? n.split("?")[0] : "";
    const ok = n && (role === "admin" ? page === "admin.html" : page !== "admin.html");
    location.href = ok ? n : (role === "admin" ? "admin.html" : "book.html");
  };

  document.getElementById("userLogin").addEventListener("submit", e => {
    e.preventDefault();
    const phone = e.target.phone.value.replace(/\s/g, ""), pass = e.target.password.value;
    const u = users().find(x => x.phone === phone && x.password === pass);
    if (!u) { msg("userMsg").textContent = "Phone number or password is incorrect."; return; }
    DB.set("cc_session", { role: "user", name: u.name, phone: u.phone });
    go("user");
  });

  document.getElementById("userRegister").addEventListener("submit", e => {
    e.preventDefault();
    const f = e.target, phone = f.phone.value.replace(/\s/g, "");
    if (!/^\d{10}$/.test(phone)) { msg("regMsg").textContent = "Enter a 10-digit phone number."; return; }
    if (f.password.value.length < 6) { msg("regMsg").textContent = "Password must be at least 6 characters."; return; }
    const list = users();
    if (list.some(x => x.phone === phone)) { msg("regMsg").textContent = "This number is already registered. Log in instead."; return; }
    list.push({ name: f.elements.name.value.trim(), phone, password: f.password.value });
    DB.set("cc_users", list);
    DB.set("cc_session", { role: "user", name: f.elements.name.value.trim(), phone });
    go("user");
  });

  document.getElementById("adminLogin").addEventListener("submit", e => {
    e.preventDefault();
    if (e.target.username.value.trim() === ADMIN.user && e.target.password.value === ADMIN.pass) {
      DB.set("cc_session", { role: "admin", name: "Admin" });
      go("admin");
    } else msg("adminMsg").textContent = "Admin username or password is incorrect.";
  });

}

/* ---------- Booking page ---------- */
function slotCount(date, slot) {
  return bookings().filter(b => b.date === date && b.slot === slot && b.status !== "Cancelled").length;
}
function initBook() {
  const s = requireRole("user");
  if (!s) return;
  const f = document.getElementById("bookForm"), q = new URLSearchParams(location.search);
  f.elements.name.value = s.name; f.phone.value = s.phone;
  f.date.min = todayISO(); f.date.value = todayISO();
  if (q.get("service")) f.service.value = q.get("service");
  if (q.get("package")) f.package.value = q.get("package");

  function fillSlots() {
    const cur = f.slot.value;
    f.slot.innerHTML = SLOTS.map(sl => {
      const full = slotCount(f.date.value, sl) >= SLOT_LIMIT;
      return '<option value="' + esc(sl) + '"' + (full ? " disabled" : "") + ">" + esc(sl) + (full ? " (full)" : "") + "</option>";
    }).join("");
    if ([...f.slot.options].some(o => o.value === cur && !o.disabled)) f.slot.value = cur;
  }
  f.date.addEventListener("change", fillSlots); fillSlots();

  f.addEventListener("submit", e => {
    e.preventDefault();
    const phone = f.phone.value.replace(/\s/g, "");
    if (!/^\d{10}$/.test(phone)) { alert("Enter a 10-digit phone number."); return; }
    if (!f.slot.value || slotCount(f.date.value, f.slot.value) >= SLOT_LIMIT) { alert("That slot is full. Please pick another."); fillSlots(); return; }
    const b = {
      id: "CC" + Date.now().toString(36).toUpperCase().slice(-5) + Math.floor(Math.random() * 90 + 10),
      userPhone: s.phone, name: f.elements.name.value.trim(), phone, address: f.address.value.trim(),
      service: f.service.value, package: f.package.value, date: f.date.value, slot: f.slot.value,
      notes: f.notes.value.trim(), status: "Pending", createdAt: new Date().toISOString()
    };
    const list = bookings(); list.push(b); DB.set("cc_bookings", list);
    const ok = document.getElementById("okBox");
    ok.hidden = false;
    ok.innerHTML = "<strong>Booking received.</strong> Your booking ID is <b>" + esc(b.id) + "</b>. " + esc(b.service) + " on " + esc(b.date) + ", " + esc(b.slot) + ". We will call you to confirm.";
    ok.scrollIntoView({ behavior: "smooth", block: "center" });
    f.notes.value = ""; fillSlots(); renderMine();
  });

  function renderMine() {
    const mine = bookings().filter(b => b.userPhone === s.phone).reverse();
    const box = document.getElementById("mine");
    if (!mine.length) { box.innerHTML = '<p class="muted">No bookings yet. Use the form to book your first visit.</p>'; return; }
    box.innerHTML = mine.map(b =>
      '<div class="mini"><div><strong>' + esc(b.service) + "</strong> · " + esc(b.package) + "<br><span class=\"muted\">" +
      esc(b.date) + ", " + esc(b.slot) + " · ID " + esc(b.id) + '</span></div><div class="mini-right"><span class="badge ' + b.status.toLowerCase() + '">' + esc(b.status) + "</span>" +
      (b.status === "Pending" || b.status === "Confirmed" ? ' <button class="link-btn" data-cancel="' + esc(b.id) + '" type="button">Cancel</button>' : "") + "</div></div>"
    ).join("");
  }
  document.getElementById("mine").addEventListener("click", e => {
    const id = e.target.dataset.cancel;
    if (!id || !confirm("Cancel this booking?")) return;
    const list = bookings(); const b = list.find(x => x.id === id);
    if (b) { b.status = "Cancelled"; DB.set("cc_bookings", list); }
    fillSlots(); renderMine();
  });
  renderMine();
}

/* ---------- Admin page ---------- */
function initAdmin() {
  if (!requireRole("admin")) return;
  const body = document.getElementById("rows"), statusF = document.getElementById("fStatus"), search = document.getElementById("fSearch");

  function view() {
    const t = search.value.trim().toLowerCase();
    return bookings().slice().reverse().filter(b =>
      (!statusF.value || b.status === statusF.value) &&
      (!t || [b.id, b.name, b.phone, b.address, b.service, b.package].join(" ").toLowerCase().includes(t)));
  }
  function render() {
    const all = bookings();
    ["Pending", "Confirmed", "Completed", "Cancelled"].forEach(st => { document.getElementById("c" + st).textContent = all.filter(b => b.status === st).length; });
    document.getElementById("cTotal").textContent = all.length;
    const rows = view();
    if (!rows.length) { body.innerHTML = '<tr><td colspan="9" class="muted center">No bookings found.</td></tr>'; return; }
    body.innerHTML = rows.map(b =>
      "<tr><td>" + esc(b.id) + "</td><td>" + esc(b.name) + "</td><td>" + esc(b.phone) + "</td><td>" + esc(b.address) + "</td><td>" +
      esc(b.service) + "</td><td>" + esc(b.package) + "</td><td>" + esc(b.date) + "<br><span class=\"muted\">" + esc(b.slot) + "</span></td><td>" +
      (b.notes ? esc(b.notes) : '<span class="muted">–</span>') + "</td><td><select data-status=\"" + esc(b.id) + "\" aria-label=\"Status for " + esc(b.id) + "\">" +
      STATUSES.map(st => "<option" + (st === b.status ? " selected" : "") + ">" + st + "</option>").join("") +
      '</select> <button class="link-btn danger" data-del="' + esc(b.id) + '" type="button">Delete</button></td></tr>'
    ).join("");
  }
  body.addEventListener("change", e => {
    const id = e.target.dataset.status; if (!id) return;
    const list = bookings(); const b = list.find(x => x.id === id);
    if (b) { b.status = e.target.value; DB.set("cc_bookings", list); render(); }
  });
  body.addEventListener("click", e => {
    const id = e.target.dataset.del;
    if (!id || !confirm("Delete booking " + id + "?")) return;
    DB.set("cc_bookings", bookings().filter(x => x.id !== id)); render();
  });
  statusF.addEventListener("change", render); search.addEventListener("input", render);

  document.getElementById("csvBtn").addEventListener("click", () => {
    const head = ["ID", "Name", "Phone", "Address", "Service", "Package", "Date", "Slot", "Notes", "Status", "Created"];
    const cell = v => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
    const csv = [head.map(cell).join(",")].concat(view().map(b =>
      [b.id, b.name, b.phone, b.address, b.service, b.package, b.date, b.slot, b.notes, b.status, b.createdAt].map(cell).join(","))).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = "coolcall-bookings.csv"; a.click(); URL.revokeObjectURL(a.href);
  });
  render();
}

document.addEventListener("DOMContentLoaded", () => {
  renderAuth();
  const page = document.body.dataset.page;
  if (page === "home") initHome();
  if (page === "login") initLogin();
  if (page === "book") initBook();
  if (page === "admin") initAdmin();
});
